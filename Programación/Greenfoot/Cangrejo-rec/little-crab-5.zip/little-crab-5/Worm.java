import greenfoot.World;
import greenfoot.Actor;

/**
 * Worm. A sand worm. Very yummy. Especially crabs really like it.
 * Author: Michael Kolling
 */
public class Worm extends Animal
{

}