import greenfoot.*;  // imports Actor, World, Greenfoot, GreenfootImage

/**
 * Rock - una classe per a representar roques.
 *
 */
public class Rock extends Actor
{
    public Rock()
    {
        
    }
    
}