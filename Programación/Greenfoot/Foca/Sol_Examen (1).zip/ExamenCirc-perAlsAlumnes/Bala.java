import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bala here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bala extends Actor
{

   private static final double MAX_FORCE = 7.5;
   private static final double MIN_FORCE = 2.0;
   private static final double GRAVITY = 0.1;
   private static final int LOWEST_ANGLE = 0;
    
   private double exactX;
   private double exactY;

    
    private final double velX;
    private double velY; // positive is upwards
        

    
    public Bala(double angle, double forsa, GreenfootImage img)
    {
        double vx = getVelX(-Math.toRadians(angle), forsa);
        double vy = getVelY(-Math.toRadians(angle), forsa);
        velX = vx;
        velY = vy;      
        setImage(img);
    }   
    

    /**
     * Act - do whatever the Projectile wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        fly();        
    }    
    
    private void fly()
    {
        velY -= this.GRAVITY;
        moveTo(exactX + velX, exactY - velY);
    }
    
   
    private void moveTo(double x, double y)
    {
        Escenari world = (Escenari)getWorld();
        if (getY()>world.getHeight()-25)
        {
            world.removeObject(this);
        }
        else
        {
            setExactLocation(x, y);
        }
    }
    
    
    public void setLocation(int x, int y)
    {
        exactX = x;
        exactY = y;
        super.setLocation(x, y);
    }
    
    public void setExactLocation(double x, double y) 
    {
        exactX = x;
        exactY = y;
        this.setLocation((int) (x + 0.5), (int) (y + 0.5));
    }
    
     public static double getVelX(double angleRadians, double forceFactor)
    {
        return Math.cos(angleRadians) * (forceFactor );
    }
    
    public static double getVelY(double angleRadians, double forceFactor)
    {
        return -Math.sin(angleRadians) * (forceFactor);
    }
    
   
}