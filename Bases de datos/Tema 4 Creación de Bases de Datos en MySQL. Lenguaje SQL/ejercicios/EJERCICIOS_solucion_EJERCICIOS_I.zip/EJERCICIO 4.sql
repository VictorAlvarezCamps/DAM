CREATE TABLE IF NOT EXISTS clientes(
idcliente INT NOT NULL,
apellidoCliente CHAR(50),
PRIMARY KEY (idcliente)
);

CREATE TABLE IF NOT EXISTS pedidos(
idpedido INT NOT NULL,
idcliente INT NOT NULL,
notaspedido VARCHAR(255),
PRIMARY KEY(idpedido),
CONSTRAINT ClaveExtPedidosIdCliente FOREIGN KEY(idcliente) REFERENCES clientes(idcliente) ON DELETE CASCADE
);

/*
PARTE II

en la tabla pedidos.....

CONSTRAINT ClaveExtPedidosIdCliente FOREIGN KEY(idcliente) REFERENCES clientes(idcliente) ON DELETE SET NULL
*/