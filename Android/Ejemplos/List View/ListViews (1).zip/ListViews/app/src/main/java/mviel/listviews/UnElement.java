package mviel.listviews;

public class UnElement {

	private int idImatge;
	private String textSuperior;
	private String textInferior;

	public UnElement() {
		this.idImatge = 0;
		this.textSuperior = null;
		this.textInferior = null;
	}
	public UnElement(int idIm, String txt1, String txt2) {
		this.idImatge = idIm;
		this.textSuperior = txt1;
		this.textInferior = txt2;
	}

	public String getTextSuperior() {
		return textSuperior;
	}

	public String getTextInferior() {
		return textInferior;
	}

	public int getIdImatge() {
		return idImatge;
	}
	
	public void setIdImatge(int idImatge) {
		this.idImatge = idImatge;
	}
	public void setTextSuperior(String textSuperior) {
		this.textSuperior = textSuperior;
	}
	public void setTextInferior(String textInferior) {
		this.textInferior = textInferior;
	}

}
