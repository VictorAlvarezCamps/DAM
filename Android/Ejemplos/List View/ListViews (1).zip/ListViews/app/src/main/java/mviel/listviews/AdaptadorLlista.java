package mviel.listviews;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public  class AdaptadorLlista extends BaseAdapter {
	private Context context;
	private int idLayout;
	private ArrayList <?> entrades;
	
	public AdaptadorLlista (Context context, int idLayout, ArrayList<?> entrades) { 
		super();  
		this.context = context; 
		this.entrades = entrades; 
		this.idLayout = idLayout; 
	 }

	@Override
	//ens indica el numero d'entrades que hi ha en l'arrayList
	public int getCount() {
		// TODO Auto-generated method stub
		return entrades.size();
	}

	@Override
	//torna l'Element position de l'arrayList
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return entrades.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		 return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// M�tode que em torna un Objecte View amb la imatge i els textos necessaris
		if (convertView == null) { //convertView �s un objecte Layout que inicialment esta a null
			// Necessitem un Layout que dins continga un horitzontalLayout, amb un ImageView, un verticalLayout, i dos TextView
		    LayoutInflater vi = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		    convertView = vi.inflate(idLayout, null); //ConvertView �s eixe Layout per� sense les dades
	    }
		//El m�tode onEntrada ens ompli les dades del layout amb un element estret de l'ArrayList que cont� les dades

		if (entrades.get(position) != null) {
			TextView text_sup_entrada = (TextView) convertView.findViewById(R.id.text_superior);
			if (text_sup_entrada != null)
				text_sup_entrada.setText(((UnElement) entrades.get(position)).getTextSuperior());

			TextView text_inf_entrada = (TextView) convertView.findViewById(R.id.text_inferior);
			if (text_inf_entrada != null)
				text_inf_entrada.setText(((UnElement) entrades.get(position)).getTextInferior());

			ImageView imatge_entrada = (ImageView) convertView.findViewById(R.id.imatge);
			if (imatge_entrada != null)
				imatge_entrada.setImageResource(((UnElement) entrades.get(position)).getIdImatge());
		}

		 // Tornem eixe View amb les dades plenes.
		return convertView;
	}
	

	 
}
