package mviel.listviews;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Inici extends Activity {
	final String[] dades = new  String[]{"Dilluns","Dimarts","Dimecres","Dijous"};
	ArrayList<UnElement> dadesLlista = new ArrayList<UnElement>();
	private ListView laLlista;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inici);

		
		ArrayList<UnElement> dadesLlista = new ArrayList<UnElement>();
		dadesLlista.add(new UnElement(R.drawable.pumpkin_amazed, "Dilluns","Primer dia de la setmana"));
		dadesLlista.add(new UnElement(R.drawable.pumpkin_angry, "Dimarts","Segon dia de la setmana"));
		dadesLlista.add(new UnElement(R.drawable.pumpkin_in_love, "Dimecres", "Tercer dia de la setmana"));
		dadesLlista.add(new UnElement(R.drawable.pumpkin_happy, "Dijous", "Quart dia de la setmana"));
        dadesLlista.add(new UnElement(R.drawable.pumpkin_amazed, "Divendres","Cinqué dia de la setmana"));
        dadesLlista.add(new UnElement(R.drawable.pumpkin_angry, "Dissabte","Sisé dia de la setmana"));
        dadesLlista.add(new UnElement(R.drawable.pumpkin_in_love, "Diumenge","Seté dia de la setmana"));



        laLlista= (ListView) findViewById(R.id.lv_diesSetmana);
		laLlista.setAdapter(new AdaptadorLlista(this, R.layout.element, dadesLlista));

        //afegim un listener a la llsta
        afegeix_Listener_A_Llista();
	}
		

	public void afegeix_Listener_A_Llista(){

	
	 // Li afegim un listener per a quan seleccionem algun element de la llista.
	 laLlista.setOnItemClickListener(new OnItemClickListener() {

		 @Override
		 public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			 //Unflem el layout que utilitzar� el Toast
			 LayoutInflater vi = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			 View toastView = vi.inflate(R.layout.element, null); //toastView �s el Layout d'un element, per� sense les dades

			 toastView.setBackgroundColor(Color.BLUE);
			 //Necessitem fer-ho d'aquesta Manera, ja que un View (arg1) nom�s pot dindre un pare, i en este cas �s l'adaptador 

			 TextView ts = (TextView) arg1.findViewById(R.id.text_superior);
			 TextView ti = (TextView) arg1.findViewById(R.id.text_inferior);
			 ImageView iv = (ImageView) arg1.findViewById(R.id.imatge);

			 TextView tos = (TextView) toastView.findViewById(R.id.text_superior);
			 TextView toi = (TextView) toastView.findViewById(R.id.text_inferior);
			 ImageView tiv = (ImageView) toastView.findViewById(R.id.imatge);

			 tos.setText(ts.getText().toString());
			 toi.setText(ti.getText().toString());
			 tiv.setImageDrawable(iv.getDrawable());

			 // Creem el Toast
			 Toast t = new Toast(getApplicationContext());

			 t.setDuration(Toast.LENGTH_SHORT);
			 t.setGravity(Gravity.TOP, 0, 0);

			 t.setView(toastView);
			 t.show();

		 }
	 });
    }
	
}
