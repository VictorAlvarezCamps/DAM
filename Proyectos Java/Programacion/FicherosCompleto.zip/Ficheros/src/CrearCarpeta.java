import java.io.File;
import java.util.Scanner;


public class CrearCarpeta {

	public static void main(String[] args) {

		Scanner sc = new Scanner (System.in);
		System.out.println("Introduce un nombre de carpeta");
		boolean bool = false;
		String a = sc.nextLine();
		File file = new File("C:\\" +a);
		bool=file.delete();
		System.out.println("Se cre�? "+bool);

	}
 
}
