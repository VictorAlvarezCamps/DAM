
import java.io.*;
import java.util.Scanner;

public class CrearFicheros {

	public void escribirFichero()
	{
		Scanner sc=new Scanner (System.in); 

		File f;
		FileWriter fw = null;
		PrintWriter pw = null;
		try {
			f = new File(".\\bin\\El Quijote.txt");
			fw = new FileWriter(f);
			pw = new PrintWriter(fw);
			System.out.println("Introduce lo que deseas escribir");
			String esc = sc.nextLine();

			pw.write(esc);
			fw.close();
			pw.close();

		} 
		catch (IOException e) 
		{

			e.printStackTrace();
		}
		catch(NullPointerException nu)
		{
			nu.printStackTrace();
		}
	}
	public void leeFichero()
	{
		File f;
		FileReader fr=null;
		BufferedReader br=null;
		try{

			String cadena;
			f = new File(".\\bin\\El Quijote.txt");
			fr = new FileReader(f);
			br = new BufferedReader(fr);
			while ((cadena = br.readLine())!=null)
			{
				System.out.println(cadena);
			}


		}
		catch(NullPointerException n)
		{
			System.out.println("El nombre del fichero es erroneo");
		}
		catch(FileNotFoundException fn)
		{
			System.out.println("No se encuentra el archivo");
		} catch (IOException e) {

			e.printStackTrace();
		}
		finally
		{
			try {
				br.close();

				fr.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}





	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in); 
		CrearFicheros cf = new CrearFicheros();
		int op;

		do{
			System.out.println("Introduce 1 para Escribir, 2 para leer o 3 para salir");
			op=sc.nextInt();
			switch (op) {
			case 1:
				cf.escribirFichero();

				break;

			case 2:
				cf.leeFichero();

				break;
			case 3:
				System.exit(op);

			default:
				System.out.println("operacion incorrecta");
				break;
			}

		}while(op!=3);
	}

}
