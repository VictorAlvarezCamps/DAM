import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class LeerFichero {

	public static void main(String[] args) {
		File f;
		FileReader fr=null;
		BufferedReader br=null;
		try{

			String cadena;
			f = new File(".\\bin\\El Quijote.txt");
			fr = new FileReader(f);
			br = new BufferedReader(fr);
			while ((cadena = br.readLine())!=null)
			{
				System.out.println(cadena);
			}
			
			
		}
		catch(NullPointerException n)
		{
			System.out.println("El nombre del fichero es erroneo");
		}
		catch(FileNotFoundException fn)
		{
			System.out.println("No se encuentra el archivo");
		} catch (IOException e) {

			e.printStackTrace();
		}
		finally
		{
			try {
				br.close();

				fr.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
