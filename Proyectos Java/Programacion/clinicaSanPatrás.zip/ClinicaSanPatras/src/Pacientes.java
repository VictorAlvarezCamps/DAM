import java.util.ArrayList;
import java.util.Scanner;

public class Pacientes {
	Scanner sc;
	ArrayList <Paciente> listaPacientes;
	int nPacientes;
	String pacienteNuevo;
	String cod,nom,ape,dir,pobl,prov,fena;
	int cp,tlf;




	public Pacientes()
	{
		listaPacientes = new ArrayList<Paciente>();
	}

	public Paciente altaPaciente()
	{
		sc=new Scanner(System.in);

		System.out.println("Introduzca codigo");
		cod = sc.nextLine();			
		System.out.println("Introduzca Nombre");
		nom=sc.nextLine();
		System.out.println("Introduzca Apellido");
		ape=sc.nextLine();
		System.out.println("Introduzca Direccion");
		dir=sc.nextLine();
		System.out.println("Introduzca Poblacion");
		pobl=sc.nextLine();
		System.out.println("Intoduzca Provincia");
		prov=sc.nextLine();
		System.out.println("Introduzca Codigo Postal");
		cp=sc.nextInt();
		System.out.println("Introduzca Telefono");
		tlf=sc.nextInt();
		System.out.println("Introduzca Fecha de Nacimiento");
		fena=sc.nextLine();


		return new Paciente(cod, nom,ape,dir,pobl,prov,cp,tlf,fena); //devuelvo un valor y a su vez inicializo paciente

	}

	public void baja(ArrayList<Paciente>listaPacientes)
	{
		String asda=sc.nextLine();

		for(int i=0;i<listaPacientes.size();i++)
		{


			for(Paciente aux : listaPacientes)
			{
				if (aux.getNombre().equals(aux.getNombre()))
				{
					System.out.println("introduzca nombre del paciente");
					String nombre=sc.nextLine();

					listaPacientes.remove(nom);
					//		System.out.println(listaPacientes.get(i));

				}
			}
		}
	}



	public void Modifica (ArrayList<Paciente>listaPacientes)
	{
		int  opcion;

		System.out.println("Selecciona una modificacion");
		opcion = sc.nextInt();
		while (opcion>1&&opcion<9)
		{
			String hhh=sc.nextLine();
			switch (opcion){
			case 1:
				System.out.println("desea modificar un codigo");
				String mod = sc.nextLine();
				System.out.println("Introduzca un nuevo codigo");
				if (mod.equalsIgnoreCase("Si"))
				{
					for(Paciente aux : listaPacientes)
					{
						if(aux.getCodigo().equalsIgnoreCase(aux.getCodigo()))
						{
							String nuevCod=sc.nextLine();
							listaPacientes.get(Integer.parseInt(cod)).setCodigo(nuevCod);

						}
					}
				}
				else
				{
					break;
				}
			case 2:
				System.out.println("desea modificar un nombre");
				String mod2 = sc.nextLine();
				if(mod2.equalsIgnoreCase("Si")){
					for(Paciente aux : listaPacientes){
						if (aux.getNombre().equals(aux.getNombre()))
						{
							System.out.println("Introduzca un nuevo Nombre ");		
							String nomb=sc.nextLine();
							listaPacientes.get(Integer.parseInt(nom)).setNombre(nomb);
						}
					}
				}
				else
				{
					break;

				}

			case 3:
				System.out.println("Desea modificar un apellido?");
				String mod3 = sc.nextLine();
				if(mod3.equalsIgnoreCase("Si"))
				{
					for(Paciente aux : listaPacientes)
					{
						if(aux.getApellidos().equals(aux.getApellidos()))
						{
							System.out.println("Indique un nuevo apellido");
							String apell = sc.nextLine();
							listaPacientes.get(Integer.parseInt(ape)).setApellidos(apell);
						}
					}

				}
				else
				{
					break;
				}

			case 4:
				System.out.println("Desea modificar una Direccion");
				String mod4 = sc.nextLine();
				if(mod4.equalsIgnoreCase("Si"))
				{
					for(Paciente aux : listaPacientes)
					{
						if(aux.getDireccion().equals(aux.getDireccion()))
						{
							System.out.println("Indique una nueva Direccion");
							String direc=sc.nextLine();
							listaPacientes.get(Integer.parseInt(dir)).setDireccion(direc);
						}
					}
				}
				else
				{
					break;
				}
			case 5:
				System.out.println("Desea modificar la poblacion? ");
				String modPob = sc.nextLine();
				if(modPob.equalsIgnoreCase("Si"))
				{
					for(Paciente aux : listaPacientes)
					{

						if(aux.getPoblacion().equals(aux.getPoblacion()))
						{
							System.out.println("Indique una nueva poblacion");
							String pobla = sc.nextLine();
							listaPacientes.get(Integer.parseInt(pobl)).setPoblacion(pobla);
						}
					}
				}
				else
				{
					break;
				}

			case 6:
				System.out.println("Desea Modificar La provincia");
				String modProv = sc.nextLine();
				if(modProv.equalsIgnoreCase("Si"))
				{
					for(Paciente aux : listaPacientes)
					{
						if(aux.getProvincia().equals(aux.getProvincia()))
						{
							System.out.println("Indique una nueva provincia");
							String provi = sc.nextLine();
							listaPacientes.get(Integer.parseInt(prov)).setProvincia(provi);
						}
					}
				}
				else
				{
					break;
				}

			case 7:
				System.out.println("Desea modificar el Codigo Postal");
				String modCp= sc.nextLine();
				if(modCp.equalsIgnoreCase("Si"))
				{


					System.out.println("Indique un nuevo codigo postal");
					int codPos = sc.nextInt();
					listaPacientes.get(cp).setCodigoPostal(codPos);
				}
				else
				{
					break;
				}


			case 8:
				System.out.println("Desea cambiar un telefono?");
				String telfn =sc.nextLine();
				if(telfn.equalsIgnoreCase("Si")){
					System.out.println("Indique un nuevo Telefono");
					int telef = sc.nextInt();
					listaPacientes.get(tlf).setTelefono(telef);
				}
				else
				{

					break;
				}

			case 9:
				System.out.println("Desea Cambiar una Fecha de Nacimiento?");
				String modFech=sc.nextLine();
				if(modFech.equalsIgnoreCase("Si"))
				{
					for(Paciente aux : listaPacientes)
					{
						if(aux.getFechaNac().equals(aux.getFechaNac()))
						{
							System.out.println("Indique una nueva fecha de nacimiento");
							String fecNa = sc.nextLine();
							listaPacientes.get(Integer.parseInt(fena)).setFechaNac(fecNa);
						}
					}
				}

				else
				{
					break;
				}
			}
		}
	}




}

