import java.util.ArrayList;
import java.util.Scanner;


public class ingresados {
	Scanner sc;
	ingreso in;
	int CodigoIngreso;
	int NumHabitacion;
	int CamaPaciente;
	String FechaIngreso;
	String MedicoPaciente;
	 
	
	public void IngresarAlta(ArrayList<ingreso> ListaIngresos){
		
			sc=new Scanner(System.in);
			System.out.println();
			System.out.println("Introduce el n�mero de ingreso:");
			CodigoIngreso=sc.nextInt();
			System.out.println("Introduce el n�mero de la habitaci�n del paciente");
			NumHabitacion=sc.nextInt();
			System.out.println("Introduce el n�mero de la cama del paciente");
			CamaPaciente=sc.nextInt();
			System.out.println("Introduce la fecha de ingreso");
			FechaIngreso=sc.next();
			System.out.println("Introduce el m�dico que atender� al paciente");
			MedicoPaciente=sc.next();
			in = new ingreso(CodigoIngreso,NumHabitacion,CamaPaciente,FechaIngreso,MedicoPaciente);
			ListaIngresos.add(in);
	}
	
	public void bajas(ArrayList<ingreso> ListaIngresos){
		int num=0;
		System.out.println();
		System.out.println("Que paciente quieres dar de baja?(Introduce numero de la cama)");
		num=sc.nextInt();
		if(!ListaIngresos.isEmpty()){
			for(int i=0;i<ListaIngresos.size();i++){
				if(ListaIngresos.get(i).equals(num)){
					if(!ListaIngresos.contains(num)){
						System.out.println("No puedes dar de baja a este paciente");
					}else{
						ListaIngresos.remove(in);
					}				
				}
			}
		}else{
			System.out.println("No hay nadie para hacer una baja");
		}
	}

	public void modificar(ArrayList<ingreso> ListaIngresos) {
		int num=0;
		String opcion;
		System.out.println();
		System.out.println("Que paciente quieres modificar para dar de alta o de baja?(Introduce el numero de la cama)");
		num=sc.nextInt();
		System.out.println("Quieres dar de alta o de baja?");
		opcion=sc.next();
		if(!ListaIngresos.isEmpty()){
			if(opcion.equals("baja")){
				for(int i=0;i<ListaIngresos.size();i++){
					if(!ListaIngresos.contains(num)){
						System.out.println("No puedes dar de baja a este paciente");
					}else{
						ListaIngresos.remove(i);
					}
				}
			}
			if(opcion.equals("alta")){
				for(int i=0;i<ListaIngresos.size();i++){
					if(ListaIngresos.get(i).equals(num)){
						if(!ListaIngresos.contains(num)){
							System.out.println("No puedes dar de alta a este paciente");
						}else{
							ListaIngresos.add(in);
						}
					}
				}
			}
		}else{
			System.out.println("No puedes hacer ninguna baja o ninguna alta");
		}
	}	
}
