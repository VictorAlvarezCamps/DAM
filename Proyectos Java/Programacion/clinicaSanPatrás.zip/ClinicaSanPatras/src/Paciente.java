public class Paciente
{
	public String Codigo;
	public String Nombre;
	public String Apellidos;
	public String Direccion;
	public String Poblacion;
	public String Provincia;
	public int codigoPostal;
	public int Telefono;
	public String fechaNac;

	
	

	public Paciente(String cod, String nom, String ape, String dir,
			String pobl, String prov, int cp, int tlf, String fena) {
		super();
		this.Codigo=cod;
		this.Nombre=nom;
		this.Apellidos=ape;
		this.Direccion=dir;
		this.Poblacion=pobl;
		this.Provincia=prov;
		this.codigoPostal=cp;
		this.Telefono=tlf;
		this.fechaNac=fena;
	}

	public String getCodigo()
	{
		return Codigo;
	}

	public void setCodigo(String codigo) 
	{
		Codigo = codigo;
	}

	public String getNombre() 
	{
		return Nombre;
	}

	public void setNombre(String nombre)
	{
		Nombre = nombre;
	}

	public String getApellidos() 
	{
		return Apellidos;
	}

	public void setApellidos(String apellidos) 
	{
		Apellidos = apellidos;
	}

	public String getDireccion() 
	{
		return Direccion;
	}

	public void setDireccion(String direccion)
	{
		Direccion = direccion;
	}

	public String getPoblacion() 
	{
		return Poblacion;
	}

	public void setPoblacion(String poblacion)
	{
		Poblacion = poblacion;
	}

	public String getProvincia() 
	{
		return Provincia;
	}

	public void setProvincia(String provincia)
	{
		Provincia = provincia;
	}

	public int getCodigoPostal()
	{
		return codigoPostal;
	}

	public void setCodigoPostal(int codigoPostal)
	{
		this.codigoPostal = codigoPostal;
	}

	public int getTelefono() 
	{
		return Telefono;
	}

	public void setTelefono(int telefono)
	{
		Telefono = telefono;
	}

	public String getFechaNac() 
	{
		return fechaNac;
	}

	public void setFechaNac(String fechaNac)
	{
		this.fechaNac = fechaNac;
	}


}
