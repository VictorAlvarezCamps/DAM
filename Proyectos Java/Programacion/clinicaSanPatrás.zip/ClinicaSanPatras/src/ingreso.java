
public class ingreso {

	private int CodigoIngreso;
	private int NumHabitacion;
	private int CamaPaciente;
	private String FechaIngreso;
	private String MedicoPaciente;
	
	public ingreso(int CodigoIngreso, int NumHabitacion, int CamaPaciente, String FechaIngreso, String MedicoPaciente){
		this.CodigoIngreso = CodigoIngreso;
		this.NumHabitacion = NumHabitacion;
		this.CamaPaciente = CamaPaciente;
		this.FechaIngreso = FechaIngreso;
		this.MedicoPaciente = MedicoPaciente;
	}
	
	public int getCodigoIngreso() {
		return CodigoIngreso;
	}

	public void setCodigoIngreso(int codigoIngreso) {
		CodigoIngreso = codigoIngreso;
	}

	public int getNumHabitacion() {
		return NumHabitacion;
	}

	public void setNumHabitacion(int numHabitacion) {
		NumHabitacion = numHabitacion;
	}

	public int getCamaPaciente() {
		return CamaPaciente;
	}

	public void setCamaPaciente(int camaPaciente) {
		CamaPaciente = camaPaciente;
	}

	public String getFechaIngreso() {
		return FechaIngreso;
	}

	public void setFechaIngreso(String fechaIngreso) {
		FechaIngreso = fechaIngreso;
	}

	public String getMedicoPaciente() {
		return MedicoPaciente;
	}

	public void setMedicoPaciente(String medicoPaciente) {
		MedicoPaciente = medicoPaciente;
	}

	public ingreso get(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
