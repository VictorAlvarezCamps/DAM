import java.util.ArrayList;
import java.util.Scanner;

public class menuMedicos {
	Medicos NM;
	Scanner sc ;
	ArrayList<Medico>nombreMedicos= new ArrayList<>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		menuMedicos me = new menuMedicos();
		me.sc=new Scanner(System.in);
		me.NM = new Medicos();
		int opcion=1;
		while(opcion>0&opcion<4){
			System.out.println("------");
			System.out.println("Elige una opcion");
			System.out.println("1-Dar de alta a un codigo");
			System.out.println("2-dar de baja a un codigo");
			System.out.println("3-modificar alta o baja de un codigo");
			System.out.println("4-Dar de alta a un nombre");
			System.out.println("5-Dar de baja a un nombre");
			System.out.println("6-modificar alta o baja de un nombre");
			System.out.println("7-dar de alta a un apellido");
			System.out.println("8-dar de baja a un apellido");
			System.out.println("9-modificar alta o baja de un apellido");
			System.out.println("10-dar de alta a un telefono");
			System.out.println("11-dar de baja a un telefono");
			System.out.println("12-modificar alta o baja de un telefono");
			System.out.println("13-dar de alta a una especialidad");
			System.out.println("14-dar de baja a una especialidad");
			System.out.println("15-modificar alta o baja de una especialidad");
			System.out.println("introduce un numero");
			opcion = me.sc.nextInt();
			
			if(opcion==1){
				me.NM.altaCodigo(me.nombreMedicos);
				}else{
					if(opcion==2){
						me.NM.bajaCodigo(me.nombreMedicos);
					}if(opcion==3)
						me.NM.modiCodigo(me.nombreMedicos);
					}if(opcion==4){
						me.NM.altaNombre(me.nombreMedicos);
					}if(opcion==5){
						me.NM.bajaNombre(me.nombreMedicos);
					}if(opcion==6){
						me.NM.modiNombre(me.nombreMedicos);
					}if(opcion==7){
						me.NM.altaApellido(me.nombreMedicos);
					}if(opcion==8){
						me.NM.bajaApellido(me.nombreMedicos);
					}if(opcion==9){
						me.NM.modiApellido(me.nombreMedicos);
					}if(opcion==10){
						me.NM.altaTelefono(me.nombreMedicos);
					}if(opcion==11){
						me.NM.bajaTelefono(me.nombreMedicos);
					}if(opcion==12){
						me.NM.modiTelefono(me.nombreMedicos);
					}if(opcion==13){
						me.NM.altaEspecialidad(me.nombreMedicos);
					}if(opcion==14){
						me.NM.bajaEspecialidad(me.nombreMedicos);
					}if(opcion==15){
						me.NM.modiEspecialidad(me.nombreMedicos);
					}
			}
		}

	}
