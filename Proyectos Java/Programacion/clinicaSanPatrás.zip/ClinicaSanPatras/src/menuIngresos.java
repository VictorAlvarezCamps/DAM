import java.util.ArrayList;
import java.util.Scanner;


public class menuIngresos {
	ingresados ing;
	Scanner sc;
	ArrayList<ingreso>ListaIngresos=new ArrayList<ingreso>();
	
	public static void main(String[] args) {
		menuIngresos m = new menuIngresos();
		m.sc=new Scanner(System.in);
		m.ing = new ingresados();
		int opcion=1;
		while(opcion>0&opcion<4){
			System.out.println();
			System.out.println("Elige una opcion:");
			System.out.println("1-Dar de alta a un paciente");
			System.out.println("2-Dar de baja a un paciente");
			System.out.println("3-Modificar alta o baja de un paciente");
			System.out.println("Introduce numero");
			opcion=m.sc.nextInt();
			
			
			if(opcion==1){
				m.ing.IngresarAlta(m.ListaIngresos);
			}else{
				if(opcion==2){
					m.ing.bajas(m.ListaIngresos);
				}else{
					m.ing.modificar(m.ListaIngresos);
				}
			}
		
			//for(ingreso Li : m.ListaIngresos){
				//System.out.println(Li.getCamaPaciente());
			//}
		}
	}
}
