import java.util.Scanner;


public class menuPacientes {

	public static void main(String[] args) {


		Pacientes p = new Pacientes();
		Scanner sc= new Scanner(System.in);

		System.out.println("Seleccione 1 para dar de alta un paciente"+"\n Seleccione 2 para dar de baja un paciente"
				+"\n Seleccione 3 para modificar los datos de algun paciente"+"\n Seleccione 0 para Salir");
		int opcion=sc.nextInt();

		String k=sc.nextLine();

		while(opcion!=0)
		{

			switch(opcion)
			{



			case 1:

				System.out.println("Desea agregar un paciente");
				String preg=sc.nextLine();
				if (preg.equalsIgnoreCase("Si"))
				{
					p.listaPacientes.add(p.altaPaciente());

				}
				else 
				{
					if(preg.equalsIgnoreCase("no"))
					{
						System.exit(opcion);

					}
					break;
				}
			case 2:
				System.out.println("Desea dar de baja un paciente");
				String pre=sc.nextLine();
				if(pre.equalsIgnoreCase("Si"))
				{
					p.baja(p.listaPacientes);
				}
				else 
				{
					if(pre.equalsIgnoreCase("no"))
					{
						System.exit(opcion);

					}
					break;
				}
			case 3: 
				System.out.println("Desea Modificar algo?");
				String pr=sc.nextLine();
				if(pr.equalsIgnoreCase("Si"))
				{
					p.Modifica(p.listaPacientes);
				}
				else 
				{
					if(pr.equalsIgnoreCase("no"))
					{
						System.exit(opcion);
						
					}
					break;
				}
			case 0:
				System.out.println("Adios!");
			}
		}



	}

}
