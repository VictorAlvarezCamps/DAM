import java.util.ArrayList;
import java.util.Scanner;

public class Medicos {
	Medico me;
	Scanner sc = new Scanner (System.in);
	int codigo;
	String nombre;
	String apellidos;
	int telefono;
	String especialidad;
	static ArrayList <Medico> nombreMedicos= new ArrayList<Medico>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Medicos nm = new Medicos();
		
		nm.datos();
		nm.altaCodigo(nombreMedicos);
		nm.altaNombre(nombreMedicos);
		nm.altaApellido(nombreMedicos);
		nm.altaTelefono(nombreMedicos);
		nm.altaEspecialidad(nombreMedicos);
		nm.bajaCodigo(nombreMedicos);
		nm.bajaNombre(nombreMedicos);
		nm.bajaApellido(nombreMedicos);
		nm.bajaTelefono(nombreMedicos);
		nm.bajaEspecialidad(nombreMedicos);
		nm.modiCodigo(nombreMedicos);
		nm.modiNombre(nombreMedicos);
		nm.modiApellido(nombreMedicos);
		nm.modiTelefono(nombreMedicos);
		nm.modiEspecialidad(nombreMedicos);
		
		//nm.baja(nombreMedicos);
		//nm.Modificacion(nombreMedicos);
	}
	
	public void datos(){
		System.out.println("introduce codigo");
		codigo = sc.nextInt();
		System.out.println("nombre medico");
		nombre = sc.next();
		System.out.println("apellido medico");
		apellidos = sc.next();
		System.out.println("telefono");
		telefono = sc.nextInt();
		System.out.println("especialidad");
		especialidad = sc.next();
		me=new Medico(codigo,nombre,apellidos,telefono,especialidad);
		nombreMedicos.add(me);
		
	}
	public Medico bajaCodigo(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el numero de la baja del medico");
		int codigoBajaMedico = sc.nextInt();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getCodigo()==codigoBajaMedico){
				nombreMedico.remove(me);
				System.out.println("has dado de baja a "+codigoBajaMedico);
			}
		}
		
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
	}
	public Medico bajaNombre(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el nombre de la baja del medico");
		String bajaMedico = sc.next();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getNombre().equals(bajaMedico)){
				nombreMedico.remove(me);
				System.out.println("has dado de baja a "+bajaMedico);
			}
		}
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
	}
	
	public Medico bajaApellido(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el Apellido de la baja del medico");
		String BajaMedicoApellido = sc.next();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getApellido().equals(BajaMedicoApellido)){
				nombreMedico.remove(me);
				System.out.println("has dado de baja a "+BajaMedicoApellido);
			}
		}
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
	}
	
	public Medico bajaTelefono(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el numero de la baja del medico");
		int telefonoBajaMedico = sc.nextInt();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getTelefono()==telefonoBajaMedico){
				nombreMedico.remove(me);
				System.out.println("has dado de baja a "+telefonoBajaMedico);
			}
		}
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
	}
	
	public Medico bajaEspecialidad(ArrayList <Medico> nombreMedico){
		System.out.println("introduce la especialidad de la baja del medico");
		String BajaMedicoEspecialidad = sc.next();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getEspecialidad().equals(BajaMedicoEspecialidad)){
				nombreMedico.remove(me);
				System.out.println("has dado de baja a "+BajaMedicoEspecialidad);
			}
		}
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
	}
	
	
	public Medico altaCodigo(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el numero del nuevo medico");
		int codigoAltaMedico = sc.nextInt();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getCodigo()==codigoAltaMedico){
				nombreMedico.add(me);
				System.out.println("has dado de alta a"+codigoAltaMedico);
			}
		}
		
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
	}
	public Medico altaNombre(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el nombre del nuevo medico");
		String altaMedico = sc.next();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getNombre().equals(altaMedico)){
				nombreMedico.add(me);
				System.out.println("has dado de alta a"+altaMedico);
			}
	}
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
		
	}
	public Medico altaApellido(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el Apellido del nuevo medico");
		String AltaMedicoApellido = sc.next();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getApellido().equals(AltaMedicoApellido)){
				nombreMedico.add(me);
				System.out.println("has dado de alta a"+AltaMedicoApellido);
			}
		}
		
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);
	}
	
	public Medico altaTelefono(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el telefono del nuevo medico");
		int telefonoAltaMedico = sc.nextInt();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getTelefono()==telefonoAltaMedico){
				nombreMedico.add(me);
				System.out.println("has dado de alta a"+telefonoAltaMedico);
			}
		}
		
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);	
	}
	
	public Medico altaEspecialidad(ArrayList <Medico> nombreMedico){
		System.out.println("introduce el especialidad del nuevo medico");
		String AltaMedicoEspecialidad = sc.next();
		for(int i=0;i<nombreMedico.size();i++){
			if(nombreMedico.get(i).getEspecialidad().equals(AltaMedicoEspecialidad)){
				nombreMedico.add(me);
				System.out.println("has dado de alta a"+AltaMedicoEspecialidad);
			}
		}
		return new Medico (codigo,nombre,apellidos,telefono,especialidad);	
	}
	
	
	
	
	public Medico modiCodigo(ArrayList <Medico> nombreMedico){
		
		System.out.println("introduce la opcion de alta o baja");
		String opcionCodigo = sc.next();
		//if(!nombreMedico.isEmpty()){
			if(opcionCodigo.equals("baja")){
				System.out.println("introduce el numero de la baja del medico");
				int codigoBajaMedico = sc.nextInt();
				for(int i=0;i<nombreMedico.size();i++){
					if(nombreMedico.get(i).getCodigo()==codigoBajaMedico){
						nombreMedico.remove(me);
						System.out.println("has dado de baja a "+codigoBajaMedico);
					}else{
						System.out.println("introduce un numero correcto");
					}
				}
			}
			if(opcionCodigo.equals("alta")){
				System.out.println("introduce el numero del nuevo medico");
				int codigoAltaMedico = sc.nextInt();
				for(int i=0;i<nombreMedico.size();i++){
					if(nombreMedico.get(i).getCodigo()==codigoAltaMedico){
						nombreMedico.add(me);
						System.out.println("has dado de alta a"+codigoAltaMedico);
					}else{
						//System.out.println("introduce otro dato");
					}
					
				}	
		}
			return new Medico(codigo,nombre,apellidos,telefono,especialidad);
	}
		public Medico modiNombre(ArrayList <Medico> nombreMedico){
		
		System.out.println("introduce la opcion de alta o baja ");
		String opcionNombre = sc.next();
		//damos la baja o la alta al nombre del medico
	//	if(!nombreMedico.isEmpty()){
			if(opcionNombre.equals("baja")){
				System.out.println("introduce el nombre de la baja del medico");
				String bajaMedico = sc.next();
				for(int i=0;i<nombreMedico.size();i++){
					if(nombreMedico.get(i).getNombre().equals(bajaMedico)){
						nombreMedico.remove(me);
						System.out.println("has dado de baja a "+bajaMedico);
					
					}
				}
			}
			
			if(opcionNombre.equals("alta")){
				System.out.println("introduce el nombre del nuevo medico");
				String altaMedico = sc.next();
				for(int i=0;i<nombreMedico.size();i++){
					if(nombreMedico.get(i).getNombre().equals(altaMedico)){
						nombreMedico.add(me);
						System.out.println("has dado de alta a"+altaMedico);
					
					
				}
			}
			
		}
			return new Medico(codigo,nombre,apellidos,telefono,especialidad);
		}
		public Medico modiApellido(ArrayList <Medico> nombreMedico){
		
		System.out.println("introduce la opcion de alta o baja");
		//System.out.println("introduce la opcion de alta o baja");
		String opcionApellido = sc.next();
		//if(!nombreMedico.isEmpty()){
			if(opcionApellido.equals("baja")){
				System.out.println("introduce el Apellido de la baja del medico");
				String BajaMedicoApellido = sc.next();
				for(int i=0;i<nombreMedico.size();i++){
					if(nombreMedico.get(i).getApellido().equals(BajaMedicoApellido)){
						nombreMedico.remove(me);
						System.out.println("has dado de baja a "+BajaMedicoApellido);
					}else{
						System.out.println("introduce un numero correcto");
					}
				}
			}
			if(opcionApellido.equals("alta")){
				System.out.println("introduce el Apellido del nuevo medico");
				String AltaMedicoApellido = sc.next();
				for(int i=0;i<nombreMedico.size();i++){
					if(nombreMedico.get(i).getApellido().equals(AltaMedicoApellido)){
						nombreMedico.add(me);
						System.out.println("has dado de alta a"+AltaMedicoApellido);
					}else{
						//System.out.println("introduce otro dato");
					}
					
				}
			}
			return new Medico(codigo,nombre,apellidos,telefono,especialidad);
		}
		public Medico modiTelefono(ArrayList <Medico> nombreMedico){
			
			System.out.println("introduce la opcion de alta o baja");
			//System.out.println("introduce la opcion de alta o baja");
			String opcionTelefono = sc.next();
			//if(!nombreMedico.isEmpty()){
				if(opcionTelefono.equals("baja")){
					System.out.println("introduce el numero de la baja del medico");
					int telefonoBajaMedico = sc.nextInt();
					for(int i=0;i<nombreMedico.size();i++){
						if(nombreMedico.get(i).getTelefono()==telefonoBajaMedico){
							nombreMedico.remove(me);
							System.out.println("has dado de baja a "+telefonoBajaMedico);
						}else{
							//System.out.println("introduce un numero correcto");
						}
					}
				}
				if(opcionTelefono.equals("alta")){
					System.out.println("introduce el numero del nuevo medico");
					int telefonoAltaMedico = sc.nextInt();
					for(int i=0;i<nombreMedico.size();i++){
						if(nombreMedico.get(i).getTelefono()==telefonoAltaMedico){
							nombreMedico.add(me);
							System.out.println("has dado de alta a"+telefonoAltaMedico);
						}else{
							//System.out.println("introduce otro dato");
						}
						
					}
				}
				return new Medico(codigo,nombre,apellidos,telefono,especialidad);
		}
		public Medico modiEspecialidad(ArrayList <Medico> nombreMedico){
				
				System.out.println("introduce la opcion de alta o baja");
				//System.out.println("introduce la opcion de alta o baja");
				String opcionEspecialidad = sc.next();
				//if(!nombreMedico.isEmpty()){
					if(opcionEspecialidad.equals("baja")){
						System.out.println("introduce la especialidad de la baja del medico");
						String BajaMedicoEspecialidad = sc.next();
						for(int i=0;i<nombreMedico.size();i++){
							if(nombreMedico.get(i).getEspecialidad().equals(BajaMedicoEspecialidad)){
								nombreMedico.remove(me);
								System.out.println("has dado de baja a "+BajaMedicoEspecialidad);
							}else{
								//System.out.println("introduce un numero correcto");
							}
						}
					}
					if(opcionEspecialidad.equals("alta")){
						System.out.println("introduce el especialidad del nuevo medico");
						String AltaMedicoEspecialidad = sc.next();
						for(int i=0;i<nombreMedico.size();i++){
							if(nombreMedico.get(i).getEspecialidad().equals(AltaMedicoEspecialidad)){
								nombreMedico.add(me);
								System.out.println("has dado de alta a"+AltaMedicoEspecialidad);
							}else{
								//System.out.println("introduce otro dato");
							}
							
						}
					}
				
					return new Medico (codigo,nombre,apellidos,telefono,especialidad);
					}
		}
