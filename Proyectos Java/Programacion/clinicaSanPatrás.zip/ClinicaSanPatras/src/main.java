import java.util.Scanner;


//1� DAM

//Proyecto creado por:
//Aboubakr Boukili
//Victor �lvarez
//Felipe Gasc�n

public class main {

	Scanner sc;
	menuIngresos i;
	menuPacientes p;
	menuMedicos m;
	
	public static void main(String[] args) {
		main m = new main();
		m.sc=new Scanner(System.in);
		m.i=new menuIngresos();
		m.p=new menuPacientes();
		m.m=new menuMedicos();
		
		int opcion=1;
		
		while(opcion>0&opcion<4){
			System.out.println("�A d�nde quieres acceder?");
			System.out.println("1-Medicos");
			System.out.println("2-Pacientes");
			System.out.println("3-Ingresos");
			System.out.println();
			opcion=m.sc.nextInt();
			
			if(opcion==1){
				m.m.main(args);
			}else{
				if(opcion==2){
					m.p.main(args);
				}else{
					if(opcion==3){
						m.i.main(args);
					}
				}
			}
			
			
		}
		
		if(opcion==0 ||opcion>3){
			System.out.println("Introduce una opcion correcta");
		}
		
	}

}
