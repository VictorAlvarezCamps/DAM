import java.io.*;


public class VerDir {

	public static void main(String[] args) {
		System.out.println("Ficheros en el directorio actual:");

		File f = new File(".");

		String archivos[]=f.list();


		for (int i = 0; i < archivos.length; i++)
		{


			File ff = new File(".\\"+archivos[i]);
			System.out.println(archivos[i]+"\t"+ff.length()+"\n");
			if(ff.isFile()==true)
			{
				System.out.print("D");
			}

			if(ff.canWrite()==true)
			{
				System.out.print("W");
			}

			if(ff.canRead()==true)
			{
				System.out.print("R");
			}
			if (ff.canExecute()==true)
			{
				System.out.println("X"+"\n");
			}

		}

	}

}
